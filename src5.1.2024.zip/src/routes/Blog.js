import Navbar from "../components/Navbar";
import Footer from "../components/MyFooter";

function Blog(){
    return(
        <>
        <Navbar/> 
        <Footer/>
        </>
    )
}

export default Blog;