// import Navbar from "../../components/Navbar";
import { useState } from 'react'
import Header from "./Header";
import Home from "./Home";
import Sidebar from "./Sidebar";
import "../CSS/UserDashboard.css"
import EnrolledCourses from './EnrolledCourses';
import Exams from './Exams';

function UserDashboard() {
  const [openSidebarToggle, setOpenSidebarToggle] = useState(false)
  const [enrolledCourses,setEnrolledCourses] = useState(false);
  const [dashboard,setDashboard] = useState(true);
  const [exams,setExams] = useState(false);
  const OpenSidebar = () => {
    setOpenSidebarToggle(!openSidebarToggle);
  }
  const gotoEnrolledCoursesPage = () =>{
    setEnrolledCourses(true);
    setDashboard(false);
    setExams(false);
  }
  const gotoDashboardPage = () =>{
    setDashboard(true);
    setEnrolledCourses(false);
    setExams(false);
  }
  const gotoExamPage = () =>{
    setExams(true);
    setEnrolledCourses(false);
    setDashboard(false);
  }

  return (
    <div>
    {/* <Navbar/> */}
    <div className='grid-container'>
      <Header OpenSidebar={OpenSidebar}/>
      <Sidebar openSidebarToggle={openSidebarToggle} OpenSidebar={OpenSidebar} gotoEnrolledCoursesPage={gotoEnrolledCoursesPage} gotoDashboardPage={gotoDashboardPage} gotoExamPage={gotoExamPage}/>
      <Home dashboard={dashboard}/>
      
      <EnrolledCourses enrolledCourses={enrolledCourses}/>

      <Exams exams={exams}/>
      
    </div>
    </div>
  )
}

export default UserDashboard;
