import Navbar from "../components/Navbar";
import Footer from "../components/MyFooter";

function FreeCourse(){
    return(
        <>
        <Navbar/> 
        <Footer/>
        
        </>
    )
}

export default FreeCourse;