import React from 'react'

const Settings = ({settings}) => {
  return (
    settings &&
    <div>Settings</div>
  )
}

export default Settings