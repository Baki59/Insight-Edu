import React from 'react'

const Exams = ({exams}) => {
  return (
    exams &&
    <div>Exams</div>
  )
}

export default Exams