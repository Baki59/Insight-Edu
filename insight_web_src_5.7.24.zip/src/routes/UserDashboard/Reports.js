import React from 'react'

const Reports = ({reports}) => {
  return (
    reports &&
    <div>Reports</div>
  )
}

export default Reports