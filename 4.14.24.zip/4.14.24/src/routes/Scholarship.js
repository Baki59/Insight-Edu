import Footer from "../components/MyFooter";
import Navbar from "../components/Navbar";
function Scholarship(){
    return(
        <>
        <Navbar/> 
        <Footer/>
        
        </>
    )
}

export default Scholarship;